var config = {
    paths: {
        'magebees/fpowlcarousel': 'Magebees_Featuredproduct/js/owl.carousel.min' ,
         "magebeesFeatured": "Magebees_Featuredproduct/js/magebeesFeatured"
    },
    shim: {
        'magebees/fpowlcarousel': {
            deps: ['jquery']
        }
        
        
    }
};



